package de.fh_dortmund.swt.doppelkopf.interfaces;

public interface ToClientMessage extends Message {
	
	public String getAddressee();
	
}
